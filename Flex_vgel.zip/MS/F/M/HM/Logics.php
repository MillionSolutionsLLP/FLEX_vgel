<?php
namespace B\HM;

class Logics{
	
}