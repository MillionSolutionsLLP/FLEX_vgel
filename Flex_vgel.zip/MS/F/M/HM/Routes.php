<?php



\MS\Core\Helper\Comman::loadModuleRoute('F\HM');
