<div class="col-ms-12">   <h4 class="mbr-section-title align-center pb-3 mbr-fonts-style display-5">
        Our Official Address
            </h4></div>

<div class="col-md-6">

<div class="panel panel-default">
    

    <div class="panel-footer">  Corporate Office:</div>
    <div class="panel-body display-6">
        VIA House, Plot No. 135,<br>
        GIDC, Vapi - 396 195<br>
        Gujarat. India<br>
        Tel.: 0260 2428950, 0260 2429950<br>
    </div>


</div>


</div>

 
 <div class="col-md-6">
<div class="panel panel-default">
    

    <div class="panel-footer">  Common Effluent Treatment Plant:</div>
    <div class="panel-body display-6">
        “CETP”, N.H.No.8, Near Damanganga Bridge,<br>
        GIDC, Vapi - 396 195<br>
        Gujarat. India<br>
        Tel.: 0260 2432950, 0260 2434929<br>
    </div>


</div>

 </div>


  <div class="col-md-6">
<div class="panel panel-default">
    

    <div class="panel-footer">  Common Solid Waste Plant:</div>
    <div class="panel-body display-6">
        “CSWP”, Plot 4807 etc. Phase IV,<br>
        GIDC, Vapi - 396 195<br>
        Gujarat. India<br>
        Tel.: 0260 2427950, 0260 2435186, 0260 2990161<br>
    </div>


</div>

 </div>




  <div class="col-md-6">
<div class="panel panel-default">
    

    <div class="panel-footer">  Centre Of Excellence:</div>
    <div class="panel-body display-6">
        Near Water Filtration Plant, 1st Phase,<br>
        Survey No.863, P/864, 735/P,<br>
        GIDC, Vapi - 396 195<br>
        Gujarat. India<br>
        Tel No.: 0260 6453950, 0260 6453050<br>
    </div>


</div>


 </div>

