<div class="container-fluid">




<div class="col-lg-3">
	
@include("HM.V.Object.side")
</div>


<div class="col-lg-9">
<div class="ms-mod-tab">
@include("HM.V.Object.MasterDetails",['data'=>$data])


</div>

</div>
</div>
</div>

