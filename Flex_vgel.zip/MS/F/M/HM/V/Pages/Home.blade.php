@extends('F.L.Plate')
@section('title')
Vapi Green Enviro Limited - VGEL Vapi India
@endsection


@section('content')

<section class="cid-qTkA127IK8 mbr-fullscreen mbr-parallax-background" id="header2-1">

    

    <div class="mbr-overlay" style="opacity: 0.7; background-color: rgb(255, 255, 255);"></div>

    <div class="container align-center">
        <div class="row justify-content-md-center">
            <div class="mbr-white col-md-10">
                <h1 class="mbr-section-title mbr-bold pb-3 mbr-fonts-style display-1">Non Equity<br>Non Profit entity</h1>
                
                <p class="mbr-text pb-3 mbr-fonts-style display-7">
                    based on cooperative principles with corporate culture of management, was formed with an objective of providing a Comprehensive Environment Management Program (CEMP) for the estate.<br><br>VGEL set up a common solid waste management site in 1999 and in year 2000, commissioned first cell of Secured Landfill Constructed as per German Design based on asphalt-concrete base liners.&nbsp;<br><br>
                    We have installed end of the pipeline treatment facilities like common effluent treatment plant (CETP) and transport, storage, disposal facility for hazardous solid waste (TSDF) to control pollution levels and now focus is shifted to pollution abatement by adopting and promoting Cleaner Production, Cleaner Technology for Cleaner Development Mechanism.
                </p>
                <div class="mbr-section-btn"><a class="btn btn-md btn-primary display-4" href="{{action('\F\HM\Controller@index')}}">LEARN MORE</a></div>
            </div>
        </div>
    </div>
    
</section>

@endsection