<?php

 \MS\Core\Helper\Comman::loadRoute('HM',false);