<?php

Route::prefix('HM')->group(function () { \MS\Core\Helper\Comman::loadRoute('HM'); });