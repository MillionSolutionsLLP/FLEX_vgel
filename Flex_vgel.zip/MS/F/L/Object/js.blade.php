  <script src="{{asset('assets/web/assets/jquery/jquery.min.js')}}"></script>
  <script src="{{asset('assets/popper/popper.min.js')}}"></script>
  <script src="{{asset('assets/tether/tether.min.js')}}"></script>
  <script src="{{asset('assets/bootstrap/js/bootstrap.min.js')}}"></script>
  <script src="{{asset('assets/dropdown/js/script.min.js')}}"></script>
  <script src="{{asset('assets/touchswipe/jquery.touch-swipe.min.js')}}"></script>
  <script src="{{asset('assets/parallax/jarallax.min.js')}}"></script>
  <script src="{{asset('assets/smoothscroll/smooth-scroll.js')}}"></script>
  <script src="{{asset('assets/theme/js/script.js')}}"></script>
  <script src="{{asset('js/app.js?v='. Carbon::now()->timestamp )}}"></script>
  