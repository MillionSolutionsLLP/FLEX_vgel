<?php
namespace {namespace};

class Logics{
	
}