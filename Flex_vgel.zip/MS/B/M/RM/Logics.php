<?php
namespace B\RM;

class Logics{
	
}