<div class="col-lg-2" style="padding-left: 0px; padding-right: 2px;">
	
@include("PM.V.Object.side")
</div>


<div class="col-lg-10" style="padding-right: 0px;padding-left: 2px;">
<div class="ms-mod-tab">
@include("PM.V.Object.MasterDetails",['data'=>$data])


</div>

</div>


