<?php
namespace B\DM;

class Logics{
	
}