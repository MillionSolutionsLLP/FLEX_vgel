<?php
namespace B\TM;

class Logics{
	
}