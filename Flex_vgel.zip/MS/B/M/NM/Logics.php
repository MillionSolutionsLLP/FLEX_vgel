<?php
namespace B\NM;

class Logics{
	
}