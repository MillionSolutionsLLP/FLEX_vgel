

<div class="col-xs-12  col-sm-12 col-md-2 col-lg-2" style="padding-left: 0px; padding-right: 2px;">
@include("NM.V.Object.side")
</div>

<div class="col-xs-12 col-sm-12 col-md-10 col-lg-10" style="padding-right: 0px;padding-left: 2px;">
<div class="ms-mod-tab">
@include("NM.V.Object.MasterDetails",['data'=>$data])
</div>
</div>
