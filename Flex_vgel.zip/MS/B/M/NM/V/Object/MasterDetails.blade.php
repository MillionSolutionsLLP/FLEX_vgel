<div class="panel panel-default">
	
<div class="panel-heading"><h5><strong> <i class="glyphicon glyphicon-home"></i> News Management System</strong></h5></div>
<div class="panel-body">


<div class="col-lg-12">


@include('NM.V.Object.NewsWidget')




</div>

</div>


</div>