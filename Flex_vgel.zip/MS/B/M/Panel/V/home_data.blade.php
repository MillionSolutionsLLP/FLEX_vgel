<br>
<div class="row">

    <div class="container-fluid">
<div class="col-lg-6" >
include('B.L.Object.Home.Entry_Report')
</div>

<div class="col-lg-6 ">
include('B.L.Object.Home.Recentaly_Applied')
</div>
</div>
</div>


