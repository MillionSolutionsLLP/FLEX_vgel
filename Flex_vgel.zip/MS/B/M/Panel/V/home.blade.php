@extends('B.L.BasePlate')


@section('Page-content')
@include('Panel.V.panel_data',['data'=>[]])
@endsection

@section('Page-breadcrumb')
<li class="active ms-breadcrumb "></li>
@endsection