<div  id="error" class="alert alert-danger" role="alert">
  <span class="glyphicon glyphicon-exclamation-sign" aria-hi  en="true"></span>
  <span class="sr-only">Error Found:</span>
 
</div>