<link rel="stylesheet" type="text/css" href="{{asset('css/app.css')}}">

  <link href="{{asset('css/app.css')}}" rel="stylesheet">
    <link href="{{asset('vendor/metisMenu/metisMenu.min.css')}}" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="{{asset('dist/css/sb-admin-2.css')}}" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="{{asset('vendor/morrisjs/morris.css')}}" rel="stylesheet">

    <!-- Custom Fonts -->
   <!--  <link href="{{asset('vendor/font-awesome/css/font-awesome.min.css')}}" rel="stylesheet" type="text/css"> -->
<link rel="stylesheet" type="text/css" href="{{asset('css/font-awesome.min.css')}}">


