  <section class="menu cid-qTkzRZLJNu" once="menu" id="menu1-0">

    

    <nav class="navbar navbar-expand beta-menu navbar-dropdown align-items-center navbar-fixed-top navbar-toggleable-sm bg-color transparent">
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <div class="hamburger">
                <span></span>
                <span></span>
                <span></span>
                <span></span>
            </div>
        </button>
        <div class="menu-logo">
            <div class="navbar-brand">
                <span class="navbar-logo">
                    <a href="<?php echo e(action('\F\HM\Controller@index')); ?>">
                         <img src="assets/images/icon-180x180.png" alt="Mobirise" title="" style="height: 3.8rem;">
                    </a>
                </span>
                <span class="navbar-caption-wrap"><a class="navbar-caption text-black display-4" href="<?php echo e(action('\F\HM\Controller@index')); ?>">
                        VAPI GREEN ENVIRO LIMITED</a></span>
            </div>
        </div>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav nav-dropdown nav-right" data-app-modern-menu="true"><li class="nav-item">
                    <a class="nav-link link text-black display-4" href="<?php echo e(action('\F\HM\Controller@index')); ?>">
                        <span class="mbri-home mbr-iconfont mbr-iconfont-btn"></span>Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link link text-black display-4" href="<?php echo e(action('\F\HM\Controller@index')); ?>"><span class="mbri-globe mbr-iconfont mbr-iconfont-btn"></span>
                        
                        About Us
                    </a>
                </li><li class="nav-item"><a class="nav-link link text-black display-4" href="<?php echo e(action('\F\HM\Controller@index')); ?>"><span class="mbri-help mbr-iconfont mbr-iconfont-btn"></span>
                        News</a></li><li class="nav-item"><a class="nav-link link text-black display-4" href="<?php echo e(action('\F\HM\Controller@index')); ?>"><span class="socicon socicon-telegram mbr-iconfont mbr-iconfont-btn"></span>
                        Careers</a></li><li class="nav-item"><a class="nav-link link text-black display-4" href="<?php echo e(action('\F\HM\Controller@index')); ?>"><span class="mbri-bookmark mbr-iconfont mbr-iconfont-btn"></span>
                        Tenders</a></li><li class="nav-item"><a class="nav-link link text-black display-4" href="<?php echo e(action('\F\HM\Controller@index')); ?>"><span class="mbri-photos mbr-iconfont mbr-iconfont-btn"></span>Gallery</a></li><li class="nav-item"><a class="nav-link link text-black display-4" href="<?php echo e(action('\F\HM\Controller@index')); ?>"><span class="mbri-letter mbr-iconfont mbr-iconfont-btn"></span>Contact Us</a></li></ul>
            
        </div>
    </nav>


    
</section>