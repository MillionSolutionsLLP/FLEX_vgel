<?php $__env->startSection('title'); ?>

MS-Billing System 2.0.1 for <?php echo e(B\MAS\Model::getCompanyName()); ?> , Solution Provided by Million Solutions LLP
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


        <!-- Navigation -->
        <?php echo $__env->make('B.L.Object.Nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  
            <div class="ms-content">
                <div class="row">

                    <div class="ms-live-tab">

                        <div class="panel-heading"><?php echo $__env->yieldContent('Page-title'); ?> </div>
                        <?php echo $__env->make('B.L.Object.Error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <?php echo $__env->yieldContent('Page-content'); ?>

                    </div>

                </div>
             
            
            </div>
  



<?php $__env->stopSection(); ?>


<?php $__env->startSection('breadcrumb'); ?>
<li class="active"><?php echo e(__('panel.urhere')); ?> : </li>
<li class="active"><?php echo e(__('panel.home')); ?></li>
<?php echo $__env->yieldContent('Page-breadcrumb'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('L.root_BackEnd', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>