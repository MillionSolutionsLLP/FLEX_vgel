
<table class="table table-bordered table-hover">






    <tr>
    <th colspan="3"> <strong> Tax Details</strong> </th>
  
</tr>

	<tr>

	<th colspan="1"> <strong> Tax Name</strong> </th>
	<th colspan="1"> <strong> Tax Rate %</strong> </th>
	<th colspan="1"> <strong> Action</strong> </th>
	
</tr>



<tbody>
<?php if(count($data['table']) > 0): ?>
    
    <?php $__currentLoopData = $data['table']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
    	

    	
    	<td><?php echo e($row['TaxName']); ?></td>
    	<td><?php echo e($row['TaxRate']); ?></td>
    	<?php 
    	//action('/B/MAS/Controller@editTax', ['UniqId' => 1])
    	?>
    	<td ms-live-link="" >
    		
    		<div class="btn-group btn-default">
    		<div class="btn btn-success ms-mod-btn" ms-live-link="<?php echo e(action("\B\MAS\Controller@editTax",['UniqId'=>\MS\Core\Helper\Comman::en4url($row['UniqId'])])); ?>"><i class="glyphicon glyphicon-pencil"></i></div>
    	
    		</div>

    	</td>


    </tr>


    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php elseif(count($data['table']) == 0): ?>
 <tr ><center>
<td colspan="3"> 
 	<div class="col-lg-12 btn btn-info ms-mod-btn" ms-live-link="<?php echo e(action("\B\MAS\Controller@addTax")); ?>">Add New Tax</div></center>
</td>

 </tr>
<?php else: ?>
    Something is wrong !
<?php endif; ?>



</tbody>
	



</table>
