

<?php
$heading=[];
$headingKey=[];
//dd($data);

if(count($data['List-array'])>0){




  foreach ($data['List-array'] as $key => $value) {
    
    if(in_array($key, $data['List-display'])){

      $heading[]=ucfirst($value);
    $headingKey[]=$key;
    }else{

       $heading[]=ucfirst($value);

    }
    



  }


}else{

  $heading=$data['List-display'];
  $headingKey=$data['List-display'];

}

//dd($heading);

?>
<div class="panel panel-default ">


  <?php if(isset($data['List-title'])): ?>
 
<div  class="panel-heading panel-info"><h5 class=""> <strong><i class="glyphicon glyphicon-chevron-right"></i> <?php echo e($data['List-title']); ?>




</strong>  
</h5></div>

<?php endif; ?>
  <div class="panel-body">
  <div class="col-lg-12" style="margin-bottom: 5px;">
    

     <div class="btn-group">
        
      <?php $__currentLoopData = $data['List-btn']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $btn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      
      <?php if(array_key_exists('action',$btn)): ?>

      <?php if(array_key_exists('data',$btn)): ?>
      
      <?php if(array_key_exists('color',$btn)): ?>
      <?php echo e(Form::button("<i class='".$btn["icon"]." ' aria-hidden='true'></i> ".$btn["text"], ['class'=>'btn   ms-mod-btn '.$btn['color'].' ms-text-black' , 'ms-live-link'=>action($btn["action"],$btn['data']),] )); ?>

      <?php else: ?>
      <?php echo e(Form::button("<i class='".$btn["icon"]."' aria-hidden='true'></i> ".$btn["text"], ['class'=>'btn btn-info   ms-mod-btn'.' ms-text-black' , 'ms-live-link'=>action($btn["action"],$btn['data']),] )); ?>

      <?php endif; ?>


      <?php else: ?>
      
      <?php if(array_key_exists('color',$btn)): ?>
      <?php echo e(Form::button("<i class='".$btn["icon"]."' aria-hidden='true'></i> ".$btn["text"], ['class'=>'btn   ms-mod-btn '.$btn['color'].' ms-text-black' , 'ms-live-link'=>action($btn["action"]),] )); ?>

      <?php else: ?>
      <?php echo e(Form::button("<i class='".$btn["icon"]."' aria-hidden='true'></i> ".$btn["text"], ['class'=>'btn btn-info   ms-mod-btn ms-text-black ' , 'ms-live-link'=>action($btn["action"]),] )); ?>

      <?php endif; ?>


      <?php endif; ?>

      
      <?php else: ?>

      <?php if(array_key_exists('color',$btn)): ?>
      <?php echo e(Form::button("<i class='".$btn["icon"]."' aria-hidden='true'></i> ".$btn["text"], ['class'=>'btn  btn-frm-submit end-close '.$btn['color'].' ms-text-black'] )); ?>

      <?php else: ?>
      <?php echo e(Form::button("<i class='".$btn["icon"]."' aria-hidden='true'></i> ".$btn["text"], ['class'=>'btn btn-success  btn-frm-submit ms-text-black'] )); ?>

      <?php endif; ?>
      

      <?php endif; ?>


      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>


  </div>



</div>
      <table class="table table-responsive table-bordered table-hover">
  <tr>
     <th class="text-right">Shortcut<br><span class="label label-default">alt +  I + { 1,2,.. }</span></th>

  <?php $__currentLoopData = $heading; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $head): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <th><?php echo e($head); ?></th>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      <?php if(array_key_exists('delete-btn',$data['List-action']) or array_key_exists('edit-btn',$data['List-action'])): ?>


 <th>Action</th>

    <?php endif; ?>
  </tr>
<tbody>


  <?php $__currentLoopData = $data['List-Paginate']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $object): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <?php if(array_key_exists('view-btn',$data['List-action'])): ?>
  

  <?php if($loop->iteration < 10): ?>


  <tr class="ms-mod-btn" ms-live-link="<?php echo e(route($data['List-action']['view-btn']['method'],\MS\Core\Helper\Comman::en4url($object->$data['List-action']['view-btn']['key']))); ?>"      ms-shortcut="i+<?php echo e($loop->iteration); ?>" > 
  
    <?php elseif($loop->iteration == 10): ?>

  <tr class="ms-mod-btn" ms-live-link="<?php echo e(route($data['List-action']['view-btn']['method'],\MS\Core\Helper\Comman::en4url($object->$data['List-action']['view-btn']['key']))); ?>"      ms-shortcut="i+0" > 
  

    <?php else: ?>
  <tr class="ms-mod-btn" ms-live-link="<?php echo e(route($data['List-action']['view-btn']['method'],\MS\Core\Helper\Comman::en4url($object->$data['List-action']['view-btn']['key']))); ?>"     > 

    <?php endif; ?>
   <?php else: ?>
   <tr>

  <?php endif; ?>


 <td class="text-right"><?php echo e($loop->iteration); ?></td>
  <?php // dd($headingKey);?>
    <?php $__currentLoopData = $headingKey; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

     <td>

      <?php if((string)$object->$key ==  '0'): ?>


      <i class="fa fa-times text-danger"></i>
      <?php elseif((string )$object->$key ==  '1'): ?>


      <i class="fa fa-check text-success"></i>


      <?php else: ?>


       <?php echo e($object->$key); ?> 
      <?php endif; ?>

      </td>

        
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    <?php if(array_key_exists('edit-btn',$data['List-action']) or array_key_exists('delete-btn',$data['List-action'])): ?>

    <td>


      <div class="btn-group btn-group-xs " role="group" aria-label="...">
        <?php if(array_key_exists('edit-btn',$data['List-action'])): ?>
        <button type="button" class="btn  ms-text-black btn-success ms-mod-btn" ms-live-link="<?php echo e(route($data['List-action']['edit-btn']['method'],\MS\Core\Helper\Comman::en4url($object->$data['List-action']['edit-btn']['key']))); ?>"><i class="fa fa-pencil "></i></button>
        <?php endif; ?>
        <?php if(array_key_exists('delete-btn',$data['List-action'])): ?>
        <button type="button" class="btn btn-danger ms-text-black ms-mod-btn" ms-live-link="<?php echo e(route($data['List-action']['delete-btn']['method'],\MS\Core\Helper\Comman::en4url($object->$data['List-action']['delete-btn']['key']))); ?>"><i class="fa fa-trash"></i></button>
        <?php endif; ?>


      </div>

    </td>
    <?php endif; ?>
 

  </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   </tbody>

  
  </table>


  <div class="panel-footer">
    


<?php echo e($data['List-Paginate']->links('Pages.Paginate')); ?>


  </div>

</div>


<script type="text/javascript">


<?php echo $__env->make('L.jsFix', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


</script>