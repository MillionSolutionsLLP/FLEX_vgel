	
<?php $__env->startSection('Page-title'); ?>
<i class="<?php echo e($data['form-icon']); ?>" aria-hidden="true"></i>
<?php echo e($data['form-title']); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('Page-content'); ?>

	<div class="panel panel-default">

			<?php echo Form::open(['action' => $data['frm-action'],'method' => 'post','files' => true,'class'=>'ms-form','role'=>'form']); ?>

		<fieldset>
		<div class="panel-body bg-warning">
		<?php echo $data['form-content']; ?>
		</div>

		<div class="panel-footer bg-info ">
			<center class="">
			<div class="btn-group">
				
			<?php $__currentLoopData = $data['form-btn']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $btn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php if(array_key_exists('action',$btn)): ?>

			<?php if(array_key_exists('data',$btn)): ?>
			
			<?php if(array_key_exists('color',$btn)): ?>
			<?php echo e(Form::button("<i class='".$btn["icon"]." ' aria-hidden='true'></i> ".$btn["text"], ['class'=>'btn   action-btn '.$btn['color'].' ms-text-black' , 'actionlink'=>action($btn["action"],$btn['data']),] )); ?>

			<?php else: ?>
			<?php echo e(Form::button("<i class='".$btn["icon"]."' aria-hidden='true'></i> ".$btn["text"], ['class'=>'btn btn-info   action-btn'.' ms-text-black' , 'actionlink'=>action($btn["action"],$btn['data']),] )); ?>

			<?php endif; ?>


			<?php else: ?>
			
			<?php if(array_key_exists('color',$btn)): ?>
			<?php echo e(Form::button("<i class='".$btn["icon"]."' aria-hidden='true'></i> ".$btn["text"], ['class'=>'btn   action-btn '.$btn['color'].' ms-text-black' , 'actionlink'=>action($btn["action"]),] )); ?>

			<?php else: ?>
			<?php echo e(Form::button("<i class='".$btn["icon"]."' aria-hidden='true'></i> ".$btn["text"], ['class'=>'btn btn-info   action-btn ms-text-black' , 'actionlink'=>action($btn["action"]),] )); ?>

			<?php endif; ?>


			<?php endif; ?>

			
			<?php else: ?>

			<?php if(array_key_exists('color',$btn)): ?>
			<?php echo e(Form::button("<i class='".$btn["icon"]."' aria-hidden='true'></i> ".$btn["text"], ['class'=>'btn  btn-frm-submit end-close '.$btn['color'].' ms-text-black'] )); ?>

			<?php else: ?>
			<?php echo e(Form::button("<i class='".$btn["icon"]."' aria-hidden='true'></i> ".$btn["text"], ['class'=>'btn btn-success  btn-frm-submit ms-text-black'] )); ?>

			<?php endif; ?>
			

			<?php endif; ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
			</center>
		
		</div>
		</fieldset>
		<?php echo Form::close(); ?>


</div>
           
<?php $__env->stopSection(); ?>


<?php echo $__env->make('B.L.Plate', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>