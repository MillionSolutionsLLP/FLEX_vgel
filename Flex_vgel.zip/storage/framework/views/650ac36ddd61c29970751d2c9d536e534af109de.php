<div class="panel panel-default">
	
<div class="panel-heading"><h5><strong> <i class="glyphicon glyphicon-home"></i> Tenders Management System</strong></h5></div>
<div class="panel-body">


<div class="col-lg-6">

<?php echo $__env->make('TM.V.Object.TenderWidget', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>



</div>

</div>


</div>