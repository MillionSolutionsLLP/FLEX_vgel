<?php 

   $company=\B\MAS\Model::getCompany();

?>

<?php $__env->startSection('title'); ?>
<?php echo e($company['NameOfBussiness']); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<section class="cid-qTkA127IK8 mbr-fullscreen mbr-parallax-background" >

    
<!-- 
    <div class="mbr-overlay" style="opacity: 0.7; background-color: rgb(255, 255, 255);"></div>
 -->
    <div class="container-fluid " style="min-height: 65vh;">
        <div class="row ">

     

            <div class="mbr-white col-md-9">

                <div class="panel panel-success">
                        
                        <div class="panel-heading">News</div>
                          <?php echo $__env->make("HM.V.Object.NewsBox",['data'=>[
                          'detailed'=>true,
                          'limit'=>10,

                          ]], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        


                </div>


            </div>

  <div class=" col-md-3 visible-lg" >
    <!-- <div class=" col-md-3 visible-lg" style="position: fixed;top:90px;right:0px;float: right; "> -->
<!--                             <div class=" col-md-2 navbar-fixed-top" > -->

         <div class="panel panel-success">
             <div class="panel-heading"> <span class="mbri-bookmark"></span> Tenders</div>
             <?php echo $__env->make("HM.V.Object.TenderBox", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

         </div>

        </div>




        </div>






    </div>



   
    
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('F.L.Plate', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>