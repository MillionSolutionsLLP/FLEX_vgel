<div class="panel panel-default">
    
<div class="panel-heading"><h5><strong> <i class="glyphicon glyphicon-home"></i> View All Booking</strong></h5></div>
<div class="panel-body">


<div class="panel-body">

<table class="table table-bordered table-hover table-responsive">






    <tr>
    <th colspan="6"> <strong> Booking List</strong> </th>
  
</tr>

	<tr>
    <th colspan="1"> <strong>  Booking ID</strong> </th>
	<th colspan="1"> <strong>  Party Name</strong> </th>
    <th colspan="1"> <strong>  Product</strong> </th>
    <th colspan="1"> <strong>  Booking Amount</strong> </th>
    <th colspan="1"> <strong>  Amount Paid</strong> </th>
	<th colspan="1"> <starong> Booking Date</strong> </th>

    <th colspan="1"> <starong> Action</strong> </th>
	
</tr>



<tbody>
<?php if(count($data['table']) > 0): ?>
    
    <?php $__currentLoopData = $data['table']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


    <tr>
    	

    	<?php
       // dd( $row);
      //  dd(\Carbon::createFromFormat('Y-m-d', $row['BookingDate'])->diffForHumans(\Carbon::now()));
        $date=\Carbon::createFromFormat('Y-m-d', $row['BookingDate'])->format('d-m-Y');
       // $comming=\Carbon::createFromFormat('Y-m-d', $row['BookingDate'])->diffForHumans(\Carbon::now());



        

        switch ($row['BookingStatus']) {
            case '0':
                $lable='info';
                break;
            

            case '1':
                $lable='warning';
                break;

            case '2':
                $lable='success';
                break;

            case '3':
                $lable='danger';
                break;



            default:
                $lable='default';
                break;
        }

        $model=new B\BM\Model (1,$row['UniqId']);


        $qun=$model->get()->sum('ProductQuantity');
        $pmArray=$model->get()->toArray();
        //dd($model->get()->toArray()) ;


        ?>
        <td> <?php echo e($row['UniqId']); ?></td>
    	<td><?php echo e($row['BookingParty']); ?></td>
        <td>
            <table class="table">
                

        <!--     <tr>
                <th>Name</th>
                <th>Qt.</th>
            </tr> -->
        
            <?php $__currentLoopData = $pmArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
            <td><?php echo e(\B\PM\Model::getProductbyId( $product['ProductCode'])['ProductName']); ?>,<?php echo e(\B\PM\Model::getProductCatagory(
                \B\PM\Model::getProductbyId( $product['ProductCode'])['ProductTypeCode']
)['ProductTypeName']); ?></td>
            <td><?php echo e($product['ProductQuantity']); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

           </table>
         </td>
        <td class="text-success"> ₹ <?php echo e($row['BookingAmount']); ?></td>
        <td class="text-success"> ₹ <?php echo e($row['BookingAmount'] + $row['BookingLostAmount']); ?></td>
        <td><?php echo e($date); ?>   <span class="label label-<?php echo e($lable); ?> ms-text-black pull-right " style="padding: 8px;"><?php echo e(\B\BM\Model::getStatusfromCode($row['BookingStatus'])); ?></span></td>

    	<?php 
    	//action('/B/MAS/Controller@editTax', ['UniqId' => 1])
    	?>
    	<td>
    		
    		<div class="btn-group btn-default">
    		<div class="btn btn-success ms-mod-btn" ms-live-link=" <?php echo e(action("\B\BM\Controller@editBooking",['UniqId'=>\MS\Core\Helper\Comman::en4url($row['UniqId'])])); ?>"><i class="glyphicon glyphicon-pencil"></i></div>

        <!--     <div class="btn btn-danger ms-mod-btn" ms-live-link=" <?php echo e(action("\B\PM\Controller@deleteProduct",['UniqId'=>\MS\Core\Helper\Comman::en4url($row['UniqId'])])); ?>"><i class="fa fa-trash"></i></div>
    	 -->
    		</div>

    	</td>


    </tr>


    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php elseif(count($data['table']) == 0): ?>
 <tr ><center>
<td colspan="4"> 
 	<div class="col-lg-12 btn btn-info ms-mod-btn" ms-live-link="<?php echo e(action('\B\BM\Controller@addBooking')); ?>">Add New Booking</div></center>
</td>

 </tr>
<?php else: ?>
    Something is wrong !
<?php endif; ?>



</tbody>
	



</table>

</div>

</div>


</div>