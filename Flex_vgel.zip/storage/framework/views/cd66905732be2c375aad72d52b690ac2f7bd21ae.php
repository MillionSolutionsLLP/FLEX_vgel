

<div class="col-xs-12  col-sm-12 col-md-2 col-lg-2" style="padding-left: 0px; padding-right: 2px;">
<?php echo $__env->make("NM.V.Object.side", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>

<div class="col-xs-12 col-sm-12 col-md-10 col-lg-10" style="padding-right: 0px;padding-left: 2px;">
<div class="ms-mod-tab">
<?php echo $__env->make("NM.V.Object.MasterDetails",['data'=>$data], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
</div>
