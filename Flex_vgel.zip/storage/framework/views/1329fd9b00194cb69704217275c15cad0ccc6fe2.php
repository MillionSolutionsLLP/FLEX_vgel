	<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
  



  <div class="panel panel-default">
      



    <div class="panel-heading" role="tab" id="headingOne">
      <h4 class="panel-title  "  >




         <div class="btn-group ms-btn-full-width" role="group" aria-label="...">
          <span class="btn btn-default collapsed  ms-btn-full-width-main text-left" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="false" aria-controls="collapseOne"><i class="fa fa-print" aria-hidden="true"></i> Publish</span>

           <span class="pull-right ms-mod-btn btn btn-default  ms-btn-full-width-side" ms-live-link="<?php echo e(action ('\B\Panel\Controller@index_mod_data')); ?>">
            
            <i class="fa fa-home" aria-hidden="true"></i>


          </span> 
        </div>
       
      </h4>

     
    </div>
    <div id="collapseOne" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne">
      <div class="panel-body list-group">
       
		  <a href="#" class="list-group-item ms-mod-btn" ms-live-link="<?php echo e(route('NM.addNews')); ?>" ms-shortcut="p+n"> <i class="fa fa-newspaper-o" aria-hidden="true"></i> Publish News <strong class="label label-default pull-right">Atl +  P + N</strong></a>

      <a href="#" class="list-group-item ms-mod-btn" ms-live-link=""> <i class="fa fa-bookmark-o" aria-hidden="true"></i> Publish Tender <strong class="label label-default pull-right">Atl +  P + T</strong></a>

      <a href="#" class="list-group-item ms-mod-btn" ms-live-link=""> <i class="fa fa-file-text-o" aria-hidden="true"></i> Publish Document <strong class="label label-default pull-right">Atl + P + D</strong></a>

  
    


      </div>
    </div>
  </div>


  <div class="panel panel-default">
      



    <div class="panel-heading" role="tab" id="headingTwo">
      <h4 class="panel-title  "  >




         <div class="btn-group ms-btn-full-width" role="group" aria-label="...">
          <span class="btn btn-default collapsed  ms-btn-full-width-main text-left" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo"><i class="fa fa-cogs" aria-hidden="true"></i> Manage</span>

           <span class="pull-right ms-mod-btn btn btn-default  ms-btn-full-width-side" ms-live-link="<?php echo e(action ('\B\Panel\Controller@index_mod_data')); ?>">
            
            <i class="fa fa-home" aria-hidden="true"></i>


          </span> 
        </div>
       
      </h4>

     
    </div>
    <div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
      <div class="panel-body list-group">
       
      <a href="#" class="list-group-item ms-mod-btn" ms-live-link=" "> <i class="fa fa-newspaper-o" aria-hidden="true"></i> Manage News <strong class="label label-default pull-right">Atl + E + N </strong></a>

      <a href="#" class="list-group-item ms-mod-btn" ms-live-link=" "> <i class="fa fa-bookmark-o" aria-hidden="true"></i> Manage Tender <strong class="label label-default pull-right">Atl + E + T</strong></a>

      <a href="#" class="list-group-item ms-mod-btn" ms-live-link=" "> <i class="fa fa-file-text-o" aria-hidden="true"></i> Manage Document <strong class="label label-default pull-right">Atl + E + D</strong></a>

  
    


      </div>
    </div>
  </div>





</div>