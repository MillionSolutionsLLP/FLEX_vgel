<!DOCTYPE html>
<html >
<head>
  <!-- Site made with Mobirise Website Builder v4.7.7, https://mobirise.com -->
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="generator" content="Mobirise v4.7.7, mobirise.com">
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
  <link rel="shortcut icon" href="assets/images/icon-180x180.png" type="image/x-icon">
  <meta name="description" content="">
  <title><?php echo $__env->yieldContent('title'); ?></title>
<?php echo $__env->make("F.L.Object.css", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  
  
  
</head>
<body>

<?php echo $__env->make("F.L.Object.Nav", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<?php echo $__env->yieldContent('content'); ?>


<?php echo $__env->make("F.L.Object.Footer", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->make("F.L.Object.js", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  


  
</body>
</html>