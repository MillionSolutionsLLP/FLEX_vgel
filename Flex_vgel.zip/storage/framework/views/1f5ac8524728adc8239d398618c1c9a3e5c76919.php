<ul class="nav navbar-nav pull-left">


	<li class="ms-live-btn ms-border" ms-breadcrumb="Modules/Master" ms-shortcut="1" ms-live-link="<?php echo e(action('\B\MAS\Controller@index')); ?>" role="presentation" ><a class="" href="#"  data-toggle="tooltip" data-placement="left" title="Press alt + 1"
 ><span class="label label-default"


		>1</span> <i class="fa fa-cogs" aria-hidden="true"></i> Master</a></li>


	<li class="ms-live-btn ms-border" ms-breadcrumb="Modules/News" ms-shortcut="2" role="presentation" ms-live-link="<?php echo e(action('\B\NM\Controller@index')); ?>"
data-toggle="tooltip" data-placement="left" title="Press alt + 2"><a href="#" ><span class="label label-default"
		>2</span> <i class="fa fa-newspaper-o" aria-hidden="true"></i> News </a></li>
	

	<li class="ms-live-btn ms-border" role="presentation" ms-breadcrumb="Modules/Tenders" ms-shortcut="3" ms-live-link="<?php echo e(action('\B\TM\Controller@index')); ?>" 
data-toggle="tooltip" data-placement="left" title="Press alt + 3"><a href="#" ><span class="label label-default"
		>3</span> <i class="fa fa-bookmark-o" aria-hidden="true"></i> Tenders </a></li>


	<li class="ms-live-btn ms-border" role="presentation" ms-breadcrumb="Modules/Documents" ms-shortcut="4" ms-live-link="<?php echo e(action('\B\DM\Controller@index')); ?>" data-toggle="tooltip" data-placement="left" title="Press alt + 4"><a href="#" ><span class="label label-default"
		
		>4</span> <i class="fa fa-file-text-o" aria-hidden="true"></i> Documents </a></li>


	<li class="ms-live-btn ms-border" role="presentation" ms-breadcrumb="Modules/Recruitment" ms-shortcut="5" ms-live-link="<?php echo e(action('\B\RM\Controller@index')); ?>" 
		data-toggle="tooltip" data-placement="left" title="Press alt + 5"><a href="#" ><span class="label label-default" 
		>5</span> <i class="fa fa-compass" aria-hidden="true"></i> Recruitment  </a></li>



</ul>	