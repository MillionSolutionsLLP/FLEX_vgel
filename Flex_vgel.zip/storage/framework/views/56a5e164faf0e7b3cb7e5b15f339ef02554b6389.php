
<?php 

$news=new \B\NM\Model();

$limit=5;

if(!isset($data))$data=[];
if(!array_key_exists('limit', $data))$data['limit']=$limit;
//dd($data);
if($news->MS_all() != null)$news=$news->MS_all()->forPage(1,$data['limit'])->toArray();
//dd($news);

?>





<?php if(array_key_exists('detailed', $data)): ?>
	<div class="panel-body" style="min-height: 65vh;">
	<table class="table table-striped table-hover" style="color:black;">

		<tr class="info">
				
				<th>Tender Title</th>
				<th>Uploaded on</th>

		</tr>
		



		<?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		 <tr>
		 		<?php //dd(Carbon::parse($value['NewsDate'])->toFormattedDateString());  ?>
		 		<td class="text-capitalize">

		 			<?php echo e($value['NewsTitle']); ?>

		 		</td>

		 		<td><?php echo e(Carbon::parse($value['NewsDate'])->toFormattedDateString()); ?></td>

		 </tr>

		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


	</table>
	</div>
<?php else: ?>


<div class="list-group" >


<?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

  <button type="button" class="list-group-item" style="text-align: justify;"><i class="fa fa-angle-double-right" aria-hidden="true"></i> <?php echo e($value['NewsTitle']); ?></button>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



<a href="<?php echo e(route('HM.News')); ?>">
  <button type="button"  class="list-group-item" style="text-align: right;"><i class="fa fa-angle-double-right" aria-hidden="true"></i>  View more..</button>
</a>


</div>



<?php endif; ?>

