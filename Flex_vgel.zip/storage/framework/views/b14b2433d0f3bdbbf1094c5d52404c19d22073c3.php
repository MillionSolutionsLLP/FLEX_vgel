  <script src="<?php echo e(asset('assets/web/assets/jquery/jquery.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/popper/popper.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/tether/tether.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/bootstrap/js/bootstrap.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/dropdown/js/script.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/touchswipe/jquery.touch-swipe.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/parallax/jarallax.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/smoothscroll/smooth-scroll.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/theme/js/script.js')); ?>"></script>
  <script src="<?php echo e(asset('js/app.js?v='. Carbon::now()->timestamp )); ?>"></script>
  