<div class="col-lg-3"> 
<table class="table table-bordered ">

<tbody>
	<tr>
	<th colspan="2"> <strong> Company Details</strong> </th>
	
</tr>
<tr>
	<td>Name of Company :</td>
	<td><strong><?php echo e($data['Master_Company_current']['NameOfBussiness']); ?></strong></td>
</tr>


<tr>
	<td>GSTIN :</td>
	<td><strong><?php echo e($data['Master_Company_current']['GstNo']); ?></strong></td>
</tr>

<tr>
	<td>CIN :</td>
	<td><strong><?php echo e($data['Master_Company_current']['CinNo']); ?></strong></td>
</tr>

<tr>
	<td>PAN :</td>
	<td><strong><?php echo e($data['Master_Company_current']['PanNo']); ?></strong></td>
</tr>

<tr>
	<th colspan="2"> <strong> Account Details</strong>  </th>
	
</tr>

<tr>
	<td>Bank Name :</td>
	<td><strong><?php echo e($data['Master_Company_current']['BankName']); ?></strong></td>
</tr>

<tr>
	<td>Account Type :</td>
	<td><strong><?php echo e($data['Master_Company_current']['AccountType']); ?></strong></td>
</tr>

<tr>
	<td>Account No :</td>
	<td><strong><?php echo e($data['Master_Company_current']['AccountNo']); ?></strong></td>
</tr>

<tr>
	<td>IFSC Code :</td>
	<td><strong><?php echo e($data['Master_Company_current']['IfscCode']); ?></strong></td>
</tr>




</tbody>
	



</table>
</div>