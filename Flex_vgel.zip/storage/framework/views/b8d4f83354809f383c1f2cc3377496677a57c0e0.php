<?php

//dd($data);



   $company=\B\MAS\Model::getCompany();


  //dd($data);
   if(count($data['news']) < 1){echo response()->view('errors.404') ; exit();}

?>

<?php $__env->startSection('title'); ?>
<?php echo e($company['NameOfBussiness']); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<section class="cid-qTkA127IK8 mbr-fullscreen mbr-parallax-background" >

    
<!-- 
    <div class="mbr-overlay" style="opacity: 0.7; background-color: rgb(255, 255, 255);"></div>
 -->
    <div class="container-fluid " style="min-height: 65vh;">
        <div class="row "  >

       <div class=" col-md-3 visible-lg" >
      <div class="panel panel-success">
             <div class="panel-heading"> <span class="mbri-bookmark"></span> News</div>
             <?php echo $__env->make("HM.V.Object.NewsBox", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

         </div>

         

        </div>

            <div class="col-md-6" >

                <div class="panel panel-success" >
                        
                        <div class="panel-heading"><i class="fa fa-newspaper-o" aria-hidden="true"></i> <?php echo e($data['news']['NewsTitle']); ?></div>
                         <?php 

                         $date=Carbon::parse($data['news']['NewsDate']);

                          $exdate=Carbon::parse($data['news']['NewsDateExp']);


                         //dd($date->toFormattedDateString());

                          ?> 
                        <div class="panel-body" >

                                      <p class=" text-justify p-5" style="text-indent: 1em;">
                            <?php echo e((string)$data['news']['NewsContent']); ?></p>
         


                             <div class="col-md-12 pb-3 mb-3 mt-3">
                                <small class="pull-right" >
                             Published on:<?php echo e($date->toFormattedDateString()); ?><br> 
                             Valid upto:<?php echo e($exdate->toFormattedDateString()); ?> 
                           
                               </small>

                           </div>
                    <?php if($data['news']['NewsFileAttchments'] ): ?>
                    <div class="col-md-12">
                            
                        <?php

                        $data['news']['NewsFileArray']=json_decode($data['news']['NewsFileArray'], true);
                           ?>

                        <?php $__currentLoopData = $data['news']['NewsFileArray']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                        <?php 


                             

                        $type=explode('/',Storage::disk('NM')->mimeType($value));

                         $typeOf=reset($type);


                         switch ($typeOf) {
                           case 'image':
                             $icon='fa-file-image-o';
                             break;
                           
                           default:
                             $icon='fa-file-text';
                             break;
                         }


                         switch (end($type)) {
                           case 'pdf':
                             $icon='fa-file-pdf-o';
                             break;
                        
                         }

                         ?>
                          <div class="card p-3 col-12 col-md-3 col-lg-3 ms-file-download" ms-link="<?php echo e(Storage::disk('NM')->url($value)); ?>" >
                <div class="card-img pb-3 " style="background-color: #CFD8DC;    text-align: left;padding: 0.5rem 2.5rem 0 2.5rem;">

               
                    <span class="fa <?php echo e($icon); ?> fa-3x"></span>

                    

                    <i  class="fa fa-paperclip pull-right fa-2x   fa-rotate-180" aria-hidden="true"></i>
                   
                </div>
                <div class="card-box" style="background-color: #efefef;    text-align: left;padding: 0.1rem 2.5rem 0 2.5rem;">
                    <h4 class="card-title mbr-fonts-style display-4"><?php echo e($key); ?>.<span class="text-lowercase"><?php echo e(end($type)); ?></span></h4>
                    <p class="mbr-text mbr-fonts-style display-7">
                      Type: <span class="text-uppercase"> <?php echo e(end($type)); ?> </span><br>Size: <?php echo e((integer) round(Storage::disk('NM')->size($value)/1024)); ?> KB</p>
                </div>
            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </div>
                    <?php endif; ?>



                </div>
                </div>


            </div>

  <div class=" col-md-3 visible-lg" >
      <div class="panel panel-success">
             <div class="panel-heading"> <span class="mbri-bookmark"></span> Tenders</div>
             <?php echo $__env->make("HM.V.Object.TenderBox", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

         </div>



        </div>






        </div>






    </div>



   
    
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('F.L.Plate', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>